	</div>
</body>
<script src="../dist/js/jquery.js"></script>
<script src="../dist/js/bootstrap.js"></script>
</html>
<?php mysqli_close($conn); ?>