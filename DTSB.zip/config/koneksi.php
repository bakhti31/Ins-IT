<?php 

$username = "username";
$password = "password";
$local = "localhost";
$db = "db_latihan";

$conn = mysqli_connect($local,$username,$password,$db)or die(mysqli_connect_error());

 ?>